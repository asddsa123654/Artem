namespace AvtoparkApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dataGridViewCars;
        private System.Windows.Forms.TextBox textBoxBrand;
        private System.Windows.Forms.TextBox textBoxModel;
        private System.Windows.Forms.TextBox textBoxYear;
        private System.Windows.Forms.TextBox textBoxStatus;
        private System.Windows.Forms.Button buttonAdd;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonEdit;

        private void InitializeComponent()
        {
            this.dataGridViewCars = new System.Windows.Forms.DataGridView();
            this.textBoxBrand = new System.Windows.Forms.TextBox();
            this.textBoxModel = new System.Windows.Forms.TextBox();
            this.textBoxYear = new System.Windows.Forms.TextBox();
            this.textBoxStatus = new System.Windows.Forms.TextBox();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonEdit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCars)).BeginInit();
            this.SuspendLayout();

            this.dataGridViewCars.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCars.Location = new System.Drawing.Point(12, 12);
            this.dataGridViewCars.Size = new System.Drawing.Size(560, 200);
            this.Controls.Add(this.dataGridViewCars);

            this.textBoxBrand.Location = new System.Drawing.Point(12, 230);
            this.textBoxBrand.PlaceholderText = "Brand";
            this.Controls.Add(this.textBoxBrand);

            this.textBoxModel.Location = new System.Drawing.Point(150, 230);
            this.textBoxModel.PlaceholderText = "Model";
            this.Controls.Add(this.textBoxModel);

            this.textBoxYear.Location = new System.Drawing.Point(290, 230);
            this.textBoxYear.PlaceholderText = "Year";
            this.Controls.Add(this.textBoxYear);

            this.textBoxStatus.Location = new System.Drawing.Point(430, 230);
            this.textBoxStatus.PlaceholderText = "Status";
            this.Controls.Add(this.textBoxStatus);

            this.buttonAdd.Location = new System.Drawing.Point(12, 270);
            this.buttonAdd.Text = "Add";
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            this.Controls.Add(this.buttonAdd);

            this.buttonDelete.Location = new System.Drawing.Point(100, 270);
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            this.Controls.Add(this.buttonDelete);

            this.buttonEdit.Location = new System.Drawing.Point(190, 270);
            this.buttonEdit.Text = "Edit";
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            this.Controls.Add(this.buttonEdit);

            this.ClientSize = new System.Drawing.Size(584, 311);
            this.Text = "Avtopark Manager";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCars)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
