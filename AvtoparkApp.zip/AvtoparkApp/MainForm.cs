using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;

namespace AvtoparkApp
{
    public partial class MainForm : Form
    {
        private BindingList<Car> carList;
        private AppDbContext dbContext;

        public MainForm()
        {
            InitializeComponent();

            dbContext = new AppDbContext();
            dbContext.Database.EnsureCreated();

            LoadCars();
        }

        private void LoadCars()
        {
            carList = new BindingList<Car>(dbContext.Cars.ToList());
            dataGridViewCars.DataSource = carList;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            var car = new Car
            {
                Brand = textBoxBrand.Text,
                Model = textBoxModel.Text,
                Year = int.Parse(textBoxYear.Text),
                Status = textBoxStatus.Text
            };

            dbContext.Cars.Add(car);
            dbContext.SaveChanges();
            LoadCars();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewCars.CurrentRow != null)
            {
                var car = (Car)dataGridViewCars.CurrentRow.DataBoundItem;
                dbContext.Cars.Remove(car);
                dbContext.SaveChanges();
                LoadCars();
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (dataGridViewCars.CurrentRow != null)
            {
                var car = (Car)dataGridViewCars.CurrentRow.DataBoundItem;
                car.Brand = textBoxBrand.Text;
                car.Model = textBoxModel.Text;
                car.Year = int.Parse(textBoxYear.Text);
                car.Status = textBoxStatus.Text;

                dbContext.SaveChanges();
                LoadCars();
            }
        }
    }
}
